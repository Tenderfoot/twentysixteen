application = {
	content = {
		width = 320,
		height = 480, 
		scale = "letterBox",
		fps = 60,
	},
}
